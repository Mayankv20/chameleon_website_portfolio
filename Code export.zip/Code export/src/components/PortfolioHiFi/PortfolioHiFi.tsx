import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { Ellipse26Icon } from './Ellipse26Icon.js';
import { Ellipse27Icon } from './Ellipse27Icon.js';
import { Ellipse28Icon } from './Ellipse28Icon.js';
import classes from './PortfolioHiFi.module.css';
import { Rectangle285Icon } from './Rectangle285Icon.js';

interface Props {
  className?: string;
}
/* @figmaId 1:3 */
export const PortfolioHiFi: FC<Props> = memo(function PortfolioHiFi(props = {}) {
  return (
    <div className={`${resets.clapyResets} ${classes.root}`}>
      <div className={classes.footer}></div>
      <div className={classes.rectangle283}></div>
      <div className={classes.cHAMELEON2022}>CHAMELEON 2022</div>
      <div className={classes.cHAMELEON}>CHAMELEON</div>
      <div className={classes.sTRIVINGTOCREATEASMARTERWORLD}>STRIVING TO CREATE A SMARTER WORLD</div>
      <div className={classes.logo}></div>
      <div className={classes.rectangle280}></div>
      <div className={classes.cONTACTUS}>CONTACT US</div>
      <div className={classes._611111111ChameleonGmailCom}>
        <div className={classes.textBlock}>+611 111 111</div>
        <div className={classes.textBlock2}>chameleon@gmail.com</div>
        <div className={classes.textBlock3}>
          <p></p>
        </div>
      </div>
      <div className={classes.image22}></div>
      <div className={classes.jOINOURNEWSLETTER}>JOIN OUR NEWSLETTER</div>
      <div className={classes.rectangle284}></div>
      <div className={classes.emailAddress}>Email Address</div>
      <div className={classes.rectangle285}>
        <Rectangle285Icon className={classes.icon} />
      </div>
      <div className={classes.sUBMIT}>SUBMIT</div>
      <div className={classes.logo2}></div>
      <div className={classes.hOME}>HOME</div>
      <div className={classes.pORTFOLIO}>PORTFOLIO</div>
      <div className={classes.bLOG}>BLOG</div>
      <div className={classes.nEWSLETTERS}>NEWSLETTERS</div>
      <div className={classes.cONTACT}>CONTACT</div>
      <div className={classes.aBOUTUS}>ABOUT US</div>
      <div className={classes.rectangle278}></div>
      <div className={classes.lOGIN}>LOGIN</div>
      <div className={classes.rectangle279}></div>
      <div className={classes.rectangle2802}></div>
      <div className={classes.rectangle281}></div>
      <div className={classes.ellipse26}>
        <Ellipse26Icon className={classes.icon2} />
      </div>
      <div className={classes.ellipse28}>
        <Ellipse28Icon className={classes.icon3} />
      </div>
      <div className={classes.ellipse27}>
        <Ellipse27Icon className={classes.icon4} />
      </div>
      <div className={classes.image30}></div>
      <div className={classes.image31}></div>
      <div className={classes.image29}></div>
      <div className={classes.horemIpsumDolorSitAmetConsecte}>
        <div className={classes.textBlock4}>
          Horem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu turpis molestie, dictum est a, mattis
          tellus. Sed dignissim, metus nec fringilla accumsan, risus sem sollicitudin lacus, ut interdum tellus elit sed
          risus. Maecenas eget condimentum velit, sit amet feugiat lectus. Class aptent taciti sociosqu ad litora
          torquent per conubia nostra, per inceptos himenaeos.{' '}
        </div>
        <div className={classes.textBlock5}>
          <p></p>
        </div>
      </div>
      <div className={classes.horemIpsumDolorSitAmetConsecte2}>
        <div className={classes.textBlock6}>
          Horem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu turpis molestie, dictum est a, mattis
          tellus. Sed dignissim, metus nec fringilla accumsan, risus sem sollicitudin lacus, ut interdum tellus elit sed
          risus. Maecenas eget condimentum velit, sit amet feugiat lectus. Class aptent taciti sociosqu ad litora
          torquent per conubia nostra, per inceptos himenaeos.{' '}
        </div>
        <div className={classes.textBlock7}>
          <p></p>
        </div>
      </div>
      <div className={classes.horemIpsumDolorSitAmetConsecte3}>
        <div className={classes.textBlock8}>
          Horem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu turpis molestie, dictum est a, mattis
          tellus. Sed dignissim, metus nec fringilla accumsan, risus sem sollicitudin lacus, ut interdum tellus elit sed
          risus. Maecenas eget condimentum velit, sit amet feugiat lectus. Class aptent taciti sociosqu ad litora
          torquent per conubia nostra, per inceptos himenaeos.{' '}
        </div>
        <div className={classes.textBlock9}>
          <p></p>
        </div>
      </div>
      <div className={classes.rectangle2782}></div>
      <div className={classes.lEARNMORE}>LEARN MORE</div>
      <div className={classes.rectangle2783}></div>
      <div className={classes.lEARNMORE2}>GITHUB</div>
      <div className={classes.image32}></div>
      <div className={classes.rectangle2784}></div>
      <div className={classes.lEARNMORE3}>LEARN MORE</div>
      <div className={classes.rectangle2785}></div>
      <div className={classes.lEARNMORE4}>GITHUB</div>
      <div className={classes.image322}></div>
      <div className={classes.rectangle2786}></div>
      <div className={classes.lEARNMORE5}>LEARN MORE</div>
      <div className={classes.rectangle2787}></div>
      <div className={classes.lEARNMORE6}>GITHUB</div>
      <div className={classes.image323}></div>
      <div className={classes.pROJECT1}>PROJECT 1</div>
      <div className={classes.pROJECT2}>PROJECT 2 </div>
      <div className={classes.pROJECT3}> PROJECT 3</div>
    </div>
  );
});
