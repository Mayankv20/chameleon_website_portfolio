import { memo, SVGProps } from 'react';

const Rectangle285Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 362 92' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path
      d='M114.238 4.07439C120.222 1.38858 126.707 0 133.266 0H315.687C341.093 0 361.687 20.5949 361.687 46V46C361.687 71.4051 341.093 92 315.687 92H130.01C125.571 92 121.157 91.3481 116.908 90.0651V90.0651C76.765 77.9439 73.1935 22.4973 111.45 5.32607L114.238 4.07439Z'
      fill='url(#paint0_linear_1_79)'
    />
    <defs>
      <linearGradient
        id='paint0_linear_1_79'
        x1={193.679}
        y1={-0.000038673}
        x2={310.326}
        y2={87.0635}
        gradientUnits='userSpaceOnUse'
      >
        <stop stopColor='#FF8D24' />
        <stop offset={0.543811} stopColor='#D6761D' />
        <stop offset={0.9999} stopColor='#FF7A00' stopOpacity={0.66} />
        <stop offset={1} stopColor='#FF7A00' stopOpacity={0.66} />
      </linearGradient>
    </defs>
  </svg>
);

const Memo = memo(Rectangle285Icon);
export { Memo as Rectangle285Icon };
